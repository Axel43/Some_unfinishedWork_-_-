<?php
/**
 * T PHP Login Registration system
 *
 * Page : Logout
 */

// start session
session_start();

// Destroy user session
unset($_SESSION['id_av']);

// Redirect to first page
header("Location: login.php");
?>
