<?php
/**
 * e: PHP Login Registration system
 *

 */

// Start Session
session_start();

// check user login
if(empty($_SESSION['id_p']))
{
    header("Location: index.php");
}
// Database connection
require __DIR__ . '/phps/database.php';
$db = DB();

// Application library 
require __DIR__ . '/phps/library.php';
$app = new Pacienti();
$cvc=new Pacienti();

$user = $app->UserDetails($_SESSION['id_p']); // get user details
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <title>Pacienti</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>

<p1>Ana are mere</p1>
</body>
</html>
