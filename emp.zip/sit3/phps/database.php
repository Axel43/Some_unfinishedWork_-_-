<?php
// database Connection variables
define('HOST', 'localhost'); // Database host name 
define('USER', 'linndows_user'); // Database user. 
define('PASSWORD', 'g0@U1d78'); // Database user password  
define('DATABASE', 'linndows_learn'); // Database name

function DB()
{
    try {
        $db = new PDO('mysql:host='.HOST.';dbname='.DATABASE.'', USER, PASSWORD);
        return $db;
    } catch (PDOException $e) {
        return "Error!: " . $e->getMessage();
        die();
    }
}
?>
