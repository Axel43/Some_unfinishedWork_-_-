<?php

class Pacienti{
  public function Progg($datast, $datafn, $idav)
    {
        try {
            $db = DB();
            $query = $db->prepare("UPDATE useri SET datas=:datast, dataf=:datafn WHERE id_p=:id_p");
            $query->bindParam("datast", $datast, PDO::PARAM_STR);
            $query->bindParam("datafn", $datafn, PDO::PARAM_STR);
 $query->bindParam("id_p", $idav, PDO::PARAM_STR);
            $query->execute();
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }
    public function Register($avocat, $email, $username, $stagiar,$grupa, $telefon, $observatii, $password)
    {
        try {
            $db = DB();
            $query = $db->prepare("INSERT INTO useri(nume, email, username, stagiar, grupa, telefon, observatii, password) VALUES (:name,:email,:username,:stagiar,:grupa,:telefon,:observatii,:password)");
            $query->bindParam("avocat", $avocat, PDO::PARAM_STR);
            $query->bindParam("email", $email, PDO::PARAM_STR);
            $query->bindParam("username", $username, PDO::PARAM_STR);
            $query->bindParam("stagiar", $stagiar, PDO::PARAM_STR);
            $query->bindParam("grupa", $grupa, PDO::PARAM_STR);
            $query->bindParam("telefon", $telefon, PDO::PARAM_STR);
            $query->bindParam("observatii", $observatii, PDO::PARAM_STR);
            $enc_password = hash('sha256', $password);
            $query->bindParam("password", $enc_password, PDO::PARAM_STR);
            $query->execute();
            return $db->lastInsertId();
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function isUsername($username){
        try {
            $db = DB();
            $query = $db->prepare("SELECT id_p FROM useri WHERE username=:username");
            $query->bindParam("username", $username, PDO::PARAM_STR);
            $query->execute();
            if ($query->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function isEmail($email)
    {
        try {
            $db = DB();
            $query = $db->prepare("SELECT id_p FROM useri WHERE email=:email");
            $query->bindParam("email", $email, PDO::PARAM_STR);
            $query->execute();
            if ($query->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }


    public function Login($username, $password)
    {
        try {
            $db = DB();
            $query = $db->prepare("SELECT id_p FROM useri WHERE (username=:username OR email=:username) AND password=:password");
            $query->bindParam("username", $username, PDO::PARAM_STR);
            $enc_password = hash('sha256', $password);
            $query->bindParam("password", $enc_password, PDO::PARAM_STR);
            $query->execute();
            if ($query->rowCount() > 0) {
                $result = $query->fetch(PDO::FETCH_OBJ);
                return $result->id_p;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }


    public function UserDetails($id_p)
    {
        try {
            $db = DB();
            $query = $db->prepare("SELECT id_p, nume, username, email, telefon, password, obs FROM useri WHERE id_p=:id_p");
            $query->bindParam("id_p", $id_p, PDO::PARAM_STR);
            $query->execute();
            if ($query->rowCount() > 0) {
                return $query->fetch(PDO::FETCH_OBJ);
            }
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }
}
