<?php class dbconnect { public $dbase; public function initDB() { $this->dbase = new PDO("mysql:host=localhost;dbname=linndows_learn;charset=latin1","linndows_user","g0@U1d78",array(PDO::ATTR_PERSISTENT => true));
        $this->dbase->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
}
?> 
